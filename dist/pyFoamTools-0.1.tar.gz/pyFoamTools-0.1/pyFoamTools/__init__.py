import sys
sys.path.insert(1, '.')